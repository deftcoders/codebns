export function isFree(price: number): boolean {
  return price === 0;
}
