export { FacebookIcon } from '@/components/icons/social/facebook';
export { InstagramIcon } from '@/components/icons/social/instagram';
export { TwitterIcon } from '@/components/icons/social/twitter';
export { YouTubeIcon } from '@/components/icons/social/youtube';
