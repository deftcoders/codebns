export const licensingData = [
  {
    id: '1',
    title: 'text-license-one-title',
    description: 'text-license-one-desc',
  },
  {
    id: '2',
    title: 'text-license-two-title',
    description: 'text-license-two-desc',
  },
  {
    id: '3',
    title: 'text-license-three-title',
    description: 'text-license-three-desc',
  },
  {
    id: '4',
    title: 'text-license-four-title',
    description: 'text-license-four-desc',
  },
  {
    id: '5',
    title: 'text-license-five-title',
    description: 'text-license-five-desc',
  },
  {
    id: '6',
    title: 'text-license-six-title',
    description: 'text-license-six-desc',
  },
  {
    id: '7',
    title: 'text-license-seven-title',
    description: 'text-license-seven-desc',
  },
  {
    id: '8',
    title: 'text-license-eight-title',
    description: 'text-license-eight-desc',
  },
  {
    id: '9',
    title: 'text-license-nine-title',
    description: 'text-license-nine-desc',
  },
];
