export const privacyPolicy = [
  {
    id: '1',
    title: 'text-privacy-one-title',
    description: 'text-privacy-one-desc',
  },
  {
    id: '2',
    title: 'text-privacy-two-title',
    description: 'text-privacy-two-desc',
  },
  {
    id: '3',
    title: 'text-privacy-three-title',
    description: 'text-privacy-three-desc',
  },
  {
    id: '4',
    title: 'text-privacy-four-title',
    description: 'text-privacy-four-desc',
  },
  {
    id: '5',
    title: 'text-privacy-five-title',
    description: 'text-privacy-five-desc',
  },
  {
    id: '6',
    title: 'text-privacy-six-title',
    description: 'text-privacy-six-desc',
  },
  {
    id: '7',
    title: 'text-privacy-seven-title',
    description: 'text-privacy-seven-desc',
  },
  {
    id: '8',
    title: 'text-privacy-eight-title',
    description: 'text-privacy-eight-desc',
  },
  {
    id: '9',
    title: 'text-privacy-nine-title',
    description: 'text-privacy-nine-desc',
  },
];
