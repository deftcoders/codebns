export const termsData = [
  {
    id: '1',
    title: 'text-terms-one-title',
    description: 'text-terms-one-desc',
  },
  {
    id: '2',
    title: 'text-terms-two-title',
    description: 'text-terms-two-desc',
  },
  {
    id: '3',
    title: 'text-terms-three-title',
    description: 'text-terms-three-desc',
  },
  {
    id: '4',
    title: 'text-terms-four-title',
    description: 'text-terms-four-desc',
  },
  {
    id: '5',
    title: 'text-terms-five-title',
    description: 'text-terms-five-desc',
  },
  {
    id: '6',
    title: 'text-terms-six-title',
    description: 'text-terms-six-desc',
  },
  {
    id: '7',
    title: 'text-terms-seven-title',
    description: 'text-terms-seven-desc',
  },
  {
    id: '8',
    title: 'text-terms-eight-title',
    description: 'text-terms-eight-desc',
  },
  {
    id: '9',
    title: 'text-terms-nine-title',
    description: 'text-terms-nine-desc',
  },
];
