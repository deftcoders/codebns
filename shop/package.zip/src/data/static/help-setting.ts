export const helpData = [
  {
    id: '1',
    title: 'text-help-one-title',
    content: 'text-help-one-desc',
  },
  {
    id: '2',
    title: 'text-help-two-title',
    content: 'text-help-two-desc',
  },
  {
    id: '3',
    title: 'text-help-three-title',
    content: 'text-help-three-desc',
  },
  {
    id: '4',
    title: 'text-help-four-title',
    content: 'text-help-four-desc',
  },
  {
    id: '5',
    title: 'text-help-five-title',
    content: 'text-help-five-desc',
  },
  {
    id: '6',
    title: 'text-help-six-title',
    content: 'text-help-six-desc',
  },
];
